package assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class basic_testlogin {
	public static String login(String uid,String pwd)
	{
		String a_result;
		 System.setProperty("Webdriver.chrome.driver","Chromedriver.exe");
		 WebDriver dr = new ChromeDriver();
		dr.get("https://jpetstore.cfapps.io/catalog");
		
		dr.findElement(By.name("username")).sendKeys(uid);
		dr.findElement(By.name("password")).sendKeys(pwd);
		dr.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[2]")).click();

		String a_eid=dr.findElement(By.xpath("//*[@id=\"firstName\"]")).getText();
		dr.close();
		return a_eid;
	}

}

