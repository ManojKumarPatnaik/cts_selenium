package assignment;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class logintest2 {
	public static String login(String uid,String pwd)
	{
		String a_result;
		 System.setProperty("Webdriver.chrome.driver","Chromedriver.exe");
		 WebDriver dr = new ChromeDriver();
		dr.get("https://jpetstore.cfapps.io/catalog");
		dr.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
	dr.findElement(By.name("username")).sendKeys(uid);
		dr.findElement(By.name("password")).sendKeys(pwd);
		dr.findElement(By.xpath("//*[@id=\"login\"]")).click();
		dr.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[3]")).click();

String s=dr.findElement(By.xpath("//*[@id=\"Catalog\"]/form/table/tbody/tr[1]/td[2]/span")).getText();
		dr.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
		dr.close();
		return s;
	}



}
