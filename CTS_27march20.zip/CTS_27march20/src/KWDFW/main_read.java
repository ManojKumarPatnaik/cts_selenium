package KWDFW;

public class main_read {
	public static void main(String[] args ) {
		String kw,loc,td;
		 excel_read excel= new  excel_read();
		for(int r=1;r<=7;r++)
		{
			kw=excel.xl_read(r,3);
			loc=excel.xl_read(r,4);
			td=excel.xl_read(r,5);
			System.out.println(kw+loc+td);
		}
		
	}

}
