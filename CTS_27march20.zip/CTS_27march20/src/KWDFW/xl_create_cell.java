package KWDFW;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class xl_create_cell {
	String filename = "C:\\Users\\lenovo\\Downloads\\Book1.xlsx",sheetname="Sheet1";
	public void write_excel2(int row, int col,String data)
	{
		//String s= null;
		
	try
	{
		File f=new File(filename);
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet(sheetname);
		XSSFRow r= sh.getRow(row);
		XSSFCell c = r.createCell(col);
		
		//s=c.getStringCellValue();
		c.setCellValue(data);
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
	}
	catch(FileNotFoundException e)
	{	e.printStackTrace();
	
	}

catch(IOException e)
	{
	e.printStackTrace();
	}
	
}


}
