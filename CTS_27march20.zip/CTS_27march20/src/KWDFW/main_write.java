package KWDFW;

public class main_write {

	public static void main(String[] args) {
		excel_write excel=new excel_write();
		excel. write_excel0(1,2,"munisha");
		excel.write_excel0(1, 3, "salma");
		excel.write_excel0(1, 4,"ammi");
		

	}

}
