package KWDFW;

public class xlwrite_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		xl_operations_write excel=new xl_operations_write();
		//xl_create_cell excel1 = new xl_create_cell();
		//xl_create_cell1 excel2 = new xl_create_cell1();	
		//String data=excel.read_excel(3,0);
		//System.out.println("Data:"+ data);
		excel.write_excel0(3,0,"excel");
		//excel1.write_excel2(2,0,"excel");
		//excel2.write_excel1(1,0,"excel");
		
		

	}

}
