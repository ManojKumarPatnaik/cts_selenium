package assignment;

import org.testng.annotations.Test;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class dataprovider_login_xl extends excel {
	logintest1 test;
  @Test(dataProvider="login_data")
  
  public void logintest(String eid,String pwd,String exp_id) {
	  test = new logintest1();
	  
	  String a_eid=test.login(eid, pwd);
	 
	  Assert.assertEquals(a_eid, exp_id);
	}
  @BeforeClass
  public void get() {
	  get_test_data();
	  
  }
@DataProvider(name="login_data")
public String[][] provide_data()
{
	return testdata;
}
}
