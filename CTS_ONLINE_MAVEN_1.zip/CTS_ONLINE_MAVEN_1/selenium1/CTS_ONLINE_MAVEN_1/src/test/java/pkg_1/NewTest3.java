package pkg_1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;




public class NewTest3{
  @Test
  public void f() {
	  System.out.println("testng maven");
	  System.setProperty("Webdriver.chrome.driver","Chromedriver.exe");
	 WebDriver dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		
  }
}
