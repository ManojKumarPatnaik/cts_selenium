package TESTS;

import org.testng.annotations.Test;

import Pages.HomePage;
import Pages.LOGIN_PAGE;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class NewTest1 {
	WebDriver dr;
	HomePage hp;
	LOGIN_PAGE lp;
	
  @Test
  public void logintest1 () {
	  hp.click_login_link();
	  lp.do_login("sk.munisha54@gmail.com","salmamuni54");
  }
  
  @BeforeClass
  public void launchbrowser() {
	  System.setProperty("Webdriver.chrome.driver","Chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
	hp= new HomePage(dr);
	lp= new LOGIN_PAGE(dr);
  }

}
