package TESTS;

import org.testng.annotations.Test;

import Pages.Loginpage1;
import Pages.ProfilePage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

public class NewTest2 {
	WebDriver dr;
	Loginpage1 lp;
	Loginpage1 tp;
	ProfilePage pp;
	
	
  @Test
  public void logintest1() {
	  String expectedTitle="Swag Labs",actualTitle,act_pn;
	  String ex_pn="Products";
		 
		 actualTitle =tp.verifytitle(); 
		 System.out.println("actualtitle: "+actualTitle);
	 Assert.assertEquals(actualTitle, expectedTitle);
		
	  lp.do_login("standard_user","secret_sauce");
	  act_pn=pp.get_profilename();
	  System.out.println("act_pn:" +act_pn);
	  Assert.assertEquals(act_pn, ex_pn);
	  
  }
  @BeforeClass
  public void launchbrowser() {
	  System.setProperty("Webdriver.chrome.driver","Chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		tp=new Loginpage1(dr);
		
		lp= new Loginpage1(dr);
		pp=new ProfilePage(dr);
		

  }

}
