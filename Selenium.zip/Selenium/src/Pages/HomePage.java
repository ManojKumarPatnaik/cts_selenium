package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	WebDriver dr1;
	By login_link= By.linkText("Log in");
	By register_link = By.linkText("Register");
	public HomePage(WebDriver dr)
	{
		this.dr1=dr;
		
	}
	public void click_register_link()
	{
		dr1.findElement(register_link).click();
		
		
	}
	public void click_login_link()
	{
		dr1.findElement(login_link).click();
		
		
	}


		

	

}
