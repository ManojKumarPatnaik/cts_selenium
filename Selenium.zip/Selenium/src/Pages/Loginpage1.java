package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Loginpage1 {
	WebDriver dr1;
	By un = By.id("user-name");
	By pwd=By.id("password");
	By login_btn = By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");
	
	public Loginpage1(WebDriver dr)
	{
		this.dr1=dr;
		
	}
	public String verifytitle()
	{
	
	String actualTitle=dr1.getTitle();
	
return actualTitle;
	
	}
	public void enter_username(String username)
	{
		dr1.findElement(un).sendKeys(username);
		
	}
	public void enter_password(String password)
	{
		dr1.findElement(pwd).sendKeys(password);
		
	}
	public void click_login_btn() {
		dr1.findElement(login_btn).click();
	}
	public void do_login(String username, String password)
	{
		this.enter_username(username);
		this.enter_password(password);
		this.click_login_btn();
	}
	/*public String verifyText()
	{
		String actualText=dr1.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div").getText();
		 String expectedText="Products";
		 Assert.assertEquals(actualText, expectedText);
		 return actualText;*/
		 

		
		
	}
	

