package com.cts.demo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class logintestcase{
	public String login() {
		
	

 {
				System.setProperty("Webdriver.chrome.driver","Chromedriver.exe");
				WebDriver dr = new ChromeDriver();
				dr.get("http://demowebshop.tricentis.com/");
				dr.findElement(By.className("ico-login")).click();
				dr.findElement(By.id("Email")).sendKeys("sk.munisha54@gmail.com");
				dr.findElement(By.id("Password")).sendKeys("salmamuni54");
				dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			String act_res = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	return act_res;
 }


	}

}
