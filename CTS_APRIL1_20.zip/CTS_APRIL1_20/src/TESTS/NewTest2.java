package TESTS;

import org.testng.annotations.Test;

import PAGES.Loginpage1;
import PAGES.ProfilePage;
import com_baseclass.utilities;
import excel_util.excel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

public class NewTest2 extends excel {
	WebDriver dr;
	Loginpage1 lp;
	Loginpage1 tp;
	ProfilePage pp;
  @Test(dataProvider ="login_data")
  public void logintest1(String eid, String pwd, String exp_eid) {
	  String expectedTitle="Swag Labs",actualTitle,act_pn;
	  String ex_pn="Products";
		 
		 actualTitle =tp.verifytitle(); 
		 System.out.println("actualtitle: "+actualTitle);
	 Assert.assertEquals(actualTitle, expectedTitle);
		
	
	lp.do_login(eid,pwd);
	  act_pn=pp.get_profilename();
	  System.out.println("act_pn:" +act_pn);
	  Assert.assertEquals(act_pn, ex_pn);
	  
  }
  @BeforeMethod
  public void launchbrowser()
  {
  dr=utilities.launch_browser("chrome","https://www.saucedemo.com/");

        tp=new Loginpage1(dr);
		
		lp= new Loginpage1(dr);
		pp=new ProfilePage(dr);
  }
  @DataProvider(name="login_data")
  
	  public String[][] provide_data()
	  {
		  return testdata;
	  }
  
  
  @BeforeClass
  public void launchbrowser1() {
	  get_test_data();
	  //System.setProperty("Webdriver.chrome.driver","Chromedriver.exe");
		// dr = new ChromeDriver();
		//dr.get("https://www.saucedemo.com/");
//tp=new Loginpage1(dr);
		
		//lp= new Loginpage1(dr);
		//pp=new ProfilePage(dr);
		
		
		
  }

}
