package PAGES;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class ProfilePage {
	By xp_profilename = By.xpath("//*[@id=\"inventory_filter_container\"]/div");
			WebDriver dr2;
	public ProfilePage(WebDriver dr)
	{
		dr2= dr;
		
	}
	public String get_profilename()
	{
		String pname=dr2.findElement(xp_profilename).getText();
		return pname;
	}

}
