package PAGES;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class ProfilePage {
	By xp_profilename = By.xpath("//*[@id=\"inventory_filter_container\"]/div");
	By addtocart= By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button");
    By product_name=By.xpath("//*[@id=\"item_4_title_link\"]/div");
	By product_price=By.className("inventory_item_price");
	By clickoncart=By.id("shopping_cart_container");
			WebDriver dr2;
	public ProfilePage(WebDriver dr)
	{
		dr2= dr;
		
	}
	public String get_profilename()
	{
		String pname=dr2.findElement(xp_profilename).getText();
		return pname;
	}
	
	public void addtocart1() {
		dr2.findElement(addtocart).click();
	}

	public void clickoncart()
	{
		dr2.findElement(clickoncart).click();
	}
	public String verifyproductname()
	{
	
	String exp_pname=dr2.findElement(product_name).getText();
	return exp_pname;
	
	}
	public  String verifyproductprice()
	{
		String exp_pprice=dr2.findElement(product_price).getText();
		return exp_pprice;
	}

}

