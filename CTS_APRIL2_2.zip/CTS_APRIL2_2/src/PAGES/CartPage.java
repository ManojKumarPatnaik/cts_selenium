package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {
	WebDriver dr3;
	By product_name1=By.xpath("//*[@id=\"item_4_title_link\"]/div");
	By product_price1= By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/div");
	public CartPage(WebDriver dr)
	{
		dr3= dr;
		
	}
	public String verifyproductname()
	{
		String act_pname=dr3.findElement(product_name1).getText();
		return act_pname;
	
	}
	public String verifyproductprice()
	{
		String act_pprice=dr3.findElement(product_price1).getText();
		String a="$"+act_pprice;
		return a;
	}

}

