package TESTS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import PAGES.CartPage;
import PAGES.Loginpage1;
import PAGES.ProfilePage;

public class Testng2{
	WebDriver dr;
	Loginpage1 lp;
	CartPage cp;
	
	ProfilePage pp;

	
	
	
  @Test
  public void verifying1() {
	  String act_pname,exp_pname,act_pprice,exp_pprice;
	 lp.do_login("standard_user","secret_sauce");
	  pp.addtocart1();
	  
	  exp_pname=pp.verifyproductname();
	  
	  pp.clickoncart();
	  act_pname= cp.verifyproductname();
	  
	  Assert.assertEquals(act_pname, exp_pname);
	  
	}
  @Test
  public void verifying2()
  
  {
	lp.do_login("standard_user","secret_sauce");
  
	  
	  pp.addtocart1();
	 String exp_pprice = pp.verifyproductprice();
	  pp.clickoncart();
	  String a = cp.verifyproductprice(); 
	  

	  Assert.assertEquals(a, exp_pprice);
  }
  
  @BeforeMethod
  public void launchbrowser()
  {
	  System.setProperty("Webdriver.chrome.driver","Chromedriver.exe");
	WebDriver dr = new ChromeDriver();
	dr.get("https://www.saucedemo.com/");
lp= new Loginpage1(dr);
	
	pp= new ProfilePage(dr);
	cp=new CartPage(dr);
	
  
}
}
