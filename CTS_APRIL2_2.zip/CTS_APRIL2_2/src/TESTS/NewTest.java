package TESTS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() { System.setProperty("Webdriver.gecko.driver","geckodriver.exe");
	WebDriver dr = new FirefoxDriver();
	dr.get("https://www.saucedemo.com/");

  }
}
